﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;

namespace DeepThought
{
    public class Term
    {
        public Term()
        {
        }
        public Dictionary<int, int> WordHz = new Dictionary<int, int>();
        public int DocHz = 0;
    }
}
